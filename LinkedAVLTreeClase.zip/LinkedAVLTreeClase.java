/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bastian
 */
public class LinkedAVLTreeClase<T extends Comparable<T>> extends LinkedBinarySearchTree<T> implements LinkedAVLTree<T>{
    public LinkedAVLTreeClase() {
        super();
    }
    public LinkedAVLTreeClase(T elem) {
        super(elem);
    }
    public void agrega(T elem) {
        NodoBin<T> temp = new NodoBin<T> (elem); 
       Comparable<T> elem2 = (Comparable<T>)elem; 
       
       if(isEmpty())
           raiz = temp; 
       else{
           NodoBin<T> actual = raiz; 
           boolean añadido = false; 
           while(!añadido){
               if(elem2.compareTo(actual.elem)<0){
                   if(actual.izq==null){
                       actual.izq=temp; 
                       añadido = true; 
                   }else 
                       actual=actual.izq; 
               }
               else{
                   if(actual.der==null){
                       actual.der = temp; 
                       añadido = true; 
                   }
                   else
                       actual = actual.der; 
               }
           }
       }
       cont++; 
       //balanceo
       NodoBin<T> actual = temp; 
       boolean check= false;
            while((actual.papa!=null)&&(!check)){
                if(actual==actual.papa.izq)
                    actual.papa.fe-=1; 
                else 
                    actual.papa.fe+=1; 
                actual=actual.papa;
                if(Math.abs(actual.fe)>1)
                    actual=balancea(actual); 
                if(actual.fe==0)
                    check=true; 
            }
    }
    

    public void elimina(T elem) {
        NodoBin<T> N, R; 
        int FEant=0; 
        try{
            N=busca(elem); 
        } catch (Exception ElementNotFoundException){
            System.out.println("El elemento no se encontró");
            return; 
        }
        cont--; 
        R=reemplazo(N);
        NodoBin<T>actual=null; 
        if(R.papa!=null)
            FEant=R.papa.fe; 
        if((R==null)&&(N==raiz)){
            raiz=null; 
            return; 
        }
        else if(R==null){
            actual=N.papa; 
            if(actual.izq==N){
                actual.izq=null; 
                actual.fe+=1;
            } else {
                actual.der=null; 
                actual.fe-=1; 
            }
        }
        else if (R==N.izq||R==N.der){
        if(N!=raiz){
            R.papa=N.papa; 
            if(N.papa.izq==N)
                N.papa.izq=R; 
            else
                N.papa.der=R; 
        } else {
            R.papa=null; 
            raiz=R; 
        }
            actual = N.papa; 
            actual.fe=N.fe; 
            if(R==N.izq)
               actual.fe+=1; 
            else
               actual.fe-=1;
        } else {
            actual=R.papa;
            if(N!=raiz){
                if(N.papa.izq==N)
                    N.papa.izq=R;
                else 
                    N.papa.der=R; 
            R.papa=N.papa; 
            } else {
                R.papa=null; 
                raiz=R; 
            }
            R.papa.izq=R.der; 
            R.izq=N.izq; 
            R.der=N.der; 
            R.fe=N.fe; 
            actual.fe+=1;  
            
        } // balanceo 
        boolean check=false, bool1;
        while(actual!=null&&!check){
            bool1=false; 
            if((Math.abs(FEant)==1)&&(actual.fe==0))
                bool1=true; 
            else
                if(Math.abs(actual.fe)>1){
                    FEant=actual.fe; 
                    actual=balancea(actual); 
                    if(actual.fe==0)
                        bool1=true; 
                    else
                        check=true; 
                } else 
                    check=true; 
            if(bool1&&actual.papa!=null){
                FEant=actual.papa.fe; 
                if(actual.papa.izq==actual)
                    actual.papa.fe+=1;
                else 
                    actual.papa.fe-=1; 
                
            }
            actual=actual.papa; 
        }
        
    }
    public NodoBin busca(T elem){
        NodoBin<T> actual = raiz;
        while(actual!=null) {
            if(actual.getElem().equals(elem)) {
                return actual;
            }
            if(elem.compareTo(actual.getElem())<0) {
                actual = actual.getIzq();
            }
            else {
                actual = actual.getDer();
            }
        }
        return null; //nunca lo encontró
    }

    private NodoBin<T> balancea(NodoBin<T> actual) {
        NodoBin<T> alfa = actual; 
          if(alfa.getFe()==-2&&alfa.getIzq().getFe()==-1){//rotación izquierda-izquierda
                NodoBin<T> beta, gamma, A, B, C, D, papa; 
                beta=alfa.getIzq(); 
                gamma=beta.getIzq(); 
                A=gamma.getIzq(); 
                B=gamma.getDer(); 
                C=beta.getDer(); 
                D=alfa.getDer(); 
                papa=alfa.getPapa();
                gamma.cuelga(A); 
                gamma.cuelga(B); 
                alfa.cuelga(C); 
                alfa.cuelga(D);
                beta.cuelga(gamma); 
                beta.cuelga(alfa); 
                if(papa==raiz){
                    raiz.setIzq(beta); 
                    beta.setPapa(raiz); 
                }
                else 
                    papa.cuelga(beta); 
                alfa.setFe(getAltura(D)-getAltura(C)); 
                gamma.setFe(getAltura(B)-getAltura(A)); 
                beta.setFe(getAltura(alfa)-getAltura(gamma)); 
                return papa; // no le actualizamos el fe
          } else if(alfa.getFe()==2&&alfa.getIzq().getFe()==1) {//derecha-derecha
                NodoBin<T> beta, gamma, A, B, C, D, papa; 
                beta=alfa.getDer(); 
                gamma=beta.getDer(); 
                A=alfa.getIzq(); 
                B=beta.getIzq(); 
                C=gamma.getIzq(); 
                D=gamma.getDer(); 
                papa=alfa.getPapa();
                gamma.cuelga(C); 
                gamma.cuelga(D); 
                alfa.cuelga(A); 
                alfa.cuelga(B);
                beta.cuelga(alfa); 
                beta.cuelga(gamma); 
                if(papa==raiz){
                    raiz.setDer(beta); 
                    beta.setPapa(raiz); 
                }
                else 
                    papa.cuelga(beta); 
                alfa.setFe(getAltura(B)-getAltura(A)); 
                gamma.setFe(getAltura(D)-getAltura(C)); 
                beta.setFe(getAltura(gamma)-getAltura(alfa)); 
                return papa; // no le actualizamos el fe
          } else if (alfa.getFe()==-2&&alfa.getIzq().getFe()==1){//izquierda-derecha
                NodoBin<T> beta, gamma, A, B, C, D, papa; 
                beta=alfa.getIzq(); 
                gamma=beta.getDer(); 
                A=beta.getIzq(); 
                B=gamma.getIzq(); 
                C=gamma.getDer(); 
                D=alfa.getDer(); 
                papa=alfa.getPapa();
                alfa.cuelga(C); 
                alfa.cuelga(D); 
                beta.cuelga(A); 
                beta.cuelga(B);
                gamma.cuelga(alfa); 
                gamma.cuelga(beta); 
                if(papa==raiz){
                    raiz.setIzq(gamma); 
                    gamma.setPapa(raiz); 
                }
                else 
                    papa.cuelga(gamma); 
                alfa.setFe(getAltura(D)-getAltura(C)); 
                beta.setFe(getAltura(B)-getAltura(A)); 
                gamma.setFe(getAltura(alfa)-getAltura(beta)); 
                
                return papa; // no le actualizamos el fe   
          } else {
                NodoBin<T> beta, gamma, A, B, C, D, papa; 
                beta=alfa.getDer(); 
                gamma=beta.getIzq(); 
                A=alfa.getIzq(); 
                B=gamma.getIzq(); 
                C=gamma.getDer(); 
                D=beta.getDer(); 
                papa=alfa.getPapa();
                alfa.cuelga(A); 
                alfa.cuelga(B); 
                beta.cuelga(C); 
                beta.cuelga(D);
                gamma.cuelga(alfa); 
                gamma.cuelga(beta); 
                if(papa==raiz){
                    raiz.setDer(gamma); 
                    gamma.setPapa(raiz); 
                }
                else 
                    papa.cuelga(gamma); 
                alfa.setFe(getAltura(B)-getAltura(A)); 
                beta.setFe(getAltura(C)-getAltura(D)); 
                gamma.setFe(getAltura(beta)-getAltura(alfa)); 
                return papa; // no le actualizamos el fe   
          }
    }

    private NodoBin<T> reemplazo(NodoBin<T> n) {
        NodoBin<T> resul = null; 
        if((n.izq==null)&&(n.der==null))
            resul=null; 
        else if ((n.izq!=null)&&(n.der==null))
            resul=n.izq; 
        else if ((n.izq==null)&&(n.der!=null))
            resul=n.der;
        else{
        NodoBin<T>actual = n.der; 
        NodoBin<T>papa = n;
        
        while(actual.izq!=null){
            papa=actual; 
            actual=actual.izq; 
        }
        if(n.der==actual)
            actual.izq=n.izq; 
        else{
            papa.izq=actual.der; 
            actual.der=n.der; 
            actual.izq=n.izq; 
        }
        resul=actual; 
        
        }
        return resul; 
    }

    private int getAltura(NodoBin<T> actual) {
        if(actual==null) {
            return 0;
        }
        int aIzq = getAltura(actual.getIzq())+1;
        int aDer = getAltura(actual.getDer())+1;
        return Math.max(aIzq, aDer); 
    }
    public void printLevelOrder() 
{ 
    int h = getAltura(raiz); 
    int i; 
    for (i=1; i<=h; i++) 
    { 
        imprimeLevel(raiz, i); 
        System.out.println(); 
    } 
} 
    private void imprimeLevel(NodoBin raiz, int level){
        if (raiz == null) 
            return; 
        if (level == 1) 
        System.out.println(raiz.elem + ", FE: " + raiz.fe); 
        else if (level > 1) { 
        imprimeLevel(raiz.izq, level-1); 
        imprimeLevel(raiz.der, level-1); 
        } 
    }
    private NodoBin antecesorComun(NodoBin a, NodoBin b){
    NodoBin<T> actual1 = a; 
    NodoBin<T> actual2 = b; 
    NodoBin<T> papa= raiz; 
    if(a==raiz)
        return a; 
    else if(b==raiz)
        return b; 
    else if(actual1.elem.compareTo(actual2.elem)>0){     
        NodoBin<T> aux1 = busca(actual1.elem, actual2.der); 
        NodoBin<T> aux2 = busca(actual2.elem, actual1.izq); 
        if(aux1!=null)
            return actual2; //actual 2 es el antecesor
        else if(aux2!=null)
            return actual1; //actual 1 es el antecesor 
        else{               //tienen un antecesor en un subarbol
            while(actual1!=raiz){
            actual1 = actual1.getPapa(); 
            NodoBin<T> aux3 = busca(actual2.elem, actual1.izq); 
            if(aux3!=null)
                return actual1; 
            }
        }
    }else if(actual1.elem.compareTo(actual2.elem)<0){
        NodoBin<T> aux1 = busca(actual2.elem, actual1.der); 
        NodoBin<T> aux2 = busca(actual1.elem, actual2.izq); 
        if(aux1!=null)
            return actual1; //actual1 es el antecesor 
        else if(aux2!=null)
            return actual2; //actual2 es el antecesor
        else{
            while(actual1!=raiz){
            actual1 = actual1.getPapa(); 
            NodoBin<T> aux3 = busca(actual2.elem, actual1.izq); 
            if(aux3!=null)
                return actual1; 
            }               //tienen un antecesor comun en un subarbol
        }
        
    } else 
        papa=raiz;
    return papa; 
    }
    public NodoBin busca(T elem, NodoBin a){
        NodoBin<T> actual = a;
        while(actual!=null) {
            if(actual.getElem().equals(elem)) {
                return actual;
            }
            if(elem.compareTo(actual.getElem())<0) {
                actual = actual.getIzq();
            }
            else {
                actual = actual.getDer();
            }
        }
        return null; //nunca lo encontró
    }
}
